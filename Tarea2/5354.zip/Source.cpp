#include <iostream>
using namespace std;


int main()
{
	cout << "Nombre:" << endl;

	char Nombre[20];

	cin >> Nombre;


	cout << "Apellido:" << endl;

	char Apellido[20];

	cin >> Apellido;


	cout << "Edad:" << endl;

	int Edad;

	cin >> Edad;


	cout << "Telefono:" << endl;

	char Telefono[20];

	cin >> Telefono; 
	
	system("cls");


	cout << "Nombre: " << Apellido <<  ", " << Nombre << ".\n"; 

	cout  << "Edad: " << Edad << " anios.\n";

	cout << "Telefono: +52" << Telefono << ".\n";

	; system
	("pause");

	return 0;







}